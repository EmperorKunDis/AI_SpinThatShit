#!/usr/bin/env python3
"""
Context Monitor Utility
=======================
Shows context usage as a progress bar in terminal.
Based on the idea from the Czech video - Dan SRB's script concept.

Usage:
    Import and use in main orchestrator, or run standalone for testing.
"""

import sys
import os

class ContextBar:
    """
    Terminal progress bar for context usage visualization.
    
    Colors:
    - Green: 0-30% (safe)
    - Yellow: 30-50% (caution)
    - Red: 50%+ (danger - handoff territory)
    """
    
    BAR_LENGTH = 40
    
    COLORS = {
        'green': '\033[92m',
        'yellow': '\033[93m',
        'red': '\033[91m',
        'dim': '\033[2m',
        'reset': '\033[0m',
        'bold': '\033[1m',
    }
    
    def __init__(self):
        self.current_percent = 0
        self.agent_name = "unknown"
    
    def _get_color(self, percent: int) -> str:
        """Get color based on percentage"""
        if percent < 30:
            return self.COLORS['green']
        elif percent < 50:
            return self.COLORS['yellow']
        else:
            return self.COLORS['red']
    
    def _create_bar(self, percent: int) -> str:
        """Create the visual bar"""
        filled = int(self.BAR_LENGTH * percent / 100)
        empty = self.BAR_LENGTH - filled
        
        color = self._get_color(percent)
        
        bar = (
            f"{self.COLORS['dim']}[{self.COLORS['reset']}"
            f"{color}{'█' * filled}{self.COLORS['reset']}"
            f"{self.COLORS['dim']}{'░' * empty}{self.COLORS['reset']}"
            f"{self.COLORS['dim']}]{self.COLORS['reset']}"
        )
        
        return bar
    
    def update(self, percent: int, agent: str = None):
        """Update and display the progress bar"""
        self.current_percent = min(100, max(0, percent))
        if agent:
            self.agent_name = agent
        
        bar = self._create_bar(self.current_percent)
        color = self._get_color(self.current_percent)
        
        status = "SAFE" if self.current_percent < 30 else "CAUTION" if self.current_percent < 50 else "HANDOFF!"
        
        line = (
            f"\r{self.COLORS['dim']}Context:{self.COLORS['reset']} "
            f"{bar} "
            f"{color}{self.COLORS['bold']}{self.current_percent:3d}%{self.COLORS['reset']} "
            f"{self.COLORS['dim']}[{self.agent_name}]{self.COLORS['reset']} "
            f"{color}{status}{self.COLORS['reset']}"
        )
        
        # Print without newline, stay on same line
        sys.stdout.write(line)
        sys.stdout.flush()
    
    def clear(self):
        """Clear the progress bar line"""
        sys.stdout.write('\r' + ' ' * 100 + '\r')
        sys.stdout.flush()
    
    def finish(self, message: str = ""):
        """Clear bar and optionally print final message"""
        self.clear()
        if message:
            print(message)


class ContextEstimator:
    """
    Estimates context usage based on various signals.
    
    Claude Code doesn't expose exact context usage, so we estimate:
    1. From explicit mentions in output
    2. From cumulative token count
    3. From operation patterns
    """
    
    # Rough estimates
    TOKENS_PER_CHAR = 0.25  # ~4 chars per token on average
    MAX_CONTEXT_TOKENS = 200000  # Claude's context window
    
    def __init__(self):
        self.total_chars_processed = 0
        self.operations_count = 0
        self.file_reads = 0
        self.file_writes = 0
    
    def add_output(self, output: str) -> int:
        """Process output and return estimated percentage"""
        self.total_chars_processed += len(output)
        
        # Count operations
        if 'read' in output.lower() or 'reading' in output.lower():
            self.file_reads += 1
        if 'write' in output.lower() or 'writing' in output.lower() or 'created' in output.lower():
            self.file_writes += 1
        
        return self.estimate_percent()
    
    def estimate_percent(self) -> int:
        """Calculate estimated context usage percentage"""
        # Base estimate from characters
        estimated_tokens = self.total_chars_processed * self.TOKENS_PER_CHAR
        
        # Add overhead for file operations (reading files adds to context)
        file_overhead = (self.file_reads * 5000) + (self.file_writes * 2000)
        estimated_tokens += file_overhead
        
        # Add overhead for each operation (tool use, etc.)
        operation_overhead = self.operations_count * 500
        estimated_tokens += operation_overhead
        
        percent = int((estimated_tokens / self.MAX_CONTEXT_TOKENS) * 100)
        return min(100, percent)
    
    def reset(self):
        """Reset counters for new session"""
        self.total_chars_processed = 0
        self.operations_count = 0
        self.file_reads = 0
        self.file_writes = 0


# Standalone test
if __name__ == "__main__":
    import time
    
    print("Context Bar Demo\n")
    
    bar = ContextBar()
    
    # Simulate progress
    for i in range(0, 101, 5):
        bar.update(i, "developer")
        time.sleep(0.3)
    
    bar.finish("\nDemo complete!")
