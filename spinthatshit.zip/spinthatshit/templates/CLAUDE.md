# CLAUDE.md - Project Instructions
# SpinThatShit Orchestrated Project

---

## Project Overview

**Project Name:** {PROJECT_NAME}
**Type:** {e.g., SaaS Application}
**Generated:** {TIMESTAMP}

{Brief description of what this project does}

---

## Tech Stack

- **Backend:** Django 5.0+ / Python 3.11+
- **Frontend:** Angular 19.2.16
- **Database:** PostgreSQL 16 with pgvector
- **Styling:** Tailwind CSS 3.4
- **State Management:** @ngrx/signals
- **API:** REST, URL structure `/api/v1/...`

---

## Quick Commands

```bash
# Run backend
cd backend && python manage.py runserver

# Run frontend
cd frontend && ng serve

# Run tests (backend)
cd backend && pytest

# Run tests (frontend)
cd frontend && ng test

# Run linter
cd backend && ruff check .
cd frontend && ng lint

# Docker
docker-compose up -d
```

---

## Project Structure

```
.
├── backend/
│   ├── api/           # API endpoints
│   ├── core/          # Core business logic
│   ├── models/        # Database models
│   └── manage.py
├── frontend/
│   ├── src/
│   │   ├── app/       # Angular components
│   │   └── assets/
│   └── angular.json
├── docker/
│   └── docker-compose.yml
├── docs/              # Documentation (READ-ONLY for agents)
└── .spinstate/        # Orchestration state
```

---

## Agent Instructions

### Git Workflow
After EVERY file edit, run:
```bash
git add -A && git commit -m "SHORT_DESCRIPTION_OF_CHANGE"
```

### Context Management
- If context reaches 50%, STOP current task
- Write summary to `.spinstate/handoff.md`
- Update `.spinstate/checklist.md` with progress
- Exit cleanly

### Before Starting
1. Read `.spinstate/journal.md` for previous agent's notes
2. Read `.spinstate/checklist.md` for current task list
3. Read `.spinstate/handoff.md` if exists

### Documentation Reference
- Architecture: `.spinstate/architecture.md`
- Plan: `.spinstate/plan.md`
- Reviews: `.spinstate/review.md`
- Test results: `.spinstate/test_report.md`

---

## Coding Standards

### Python (Backend)
- Use type hints
- Follow PEP 8
- Docstrings for public functions
- Maximum line length: 100

### TypeScript (Frontend)
- Use strict mode
- Prefer signals over observables
- Component naming: `feature.component.ts`
- Service naming: `feature.service.ts`

### General
- No hardcoded values - use environment variables
- No empty try/catch blocks
- Meaningful variable names
- Comments for complex logic only

---

## Environment Variables

```env
# Backend
DATABASE_URL=postgresql://user:pass@localhost:5432/dbname
SECRET_KEY=your-secret-key
DEBUG=True

# Frontend
API_URL=http://localhost:8000/api/v1
```

---

## API Patterns

### Endpoints
- List: `GET /api/v1/{resource}/`
- Detail: `GET /api/v1/{resource}/{id}/`
- Create: `POST /api/v1/{resource}/`
- Update: `PUT /api/v1/{resource}/{id}/`
- Delete: `DELETE /api/v1/{resource}/{id}/`

### Response Format
```json
{
    "success": true,
    "data": { ... },
    "meta": {
        "page": 1,
        "total": 100
    }
}
```

### Error Format
```json
{
    "success": false,
    "error": {
        "code": "VALIDATION_ERROR",
        "message": "Description",
        "details": { ... }
    }
}
```

---

## Important Notes

### Pricing Tiers (CZK)
- Basic: 990 CZK/month
- Pro: 2,490 CZK/month
- Enterprise: 7,490 CZK/month

### Do NOT
- Push directly to main branch during development
- Delete existing tests
- Hardcode credentials
- Ignore type errors
- Skip git commits

### Do
- Write tests for new features
- Update documentation
- Use meaningful commit messages
- Check existing patterns before creating new ones
- Ask (via handoff notes) if unclear

---

## Contact / Escalation

If stuck or need human decision:
1. Document the issue in `.spinstate/journal.md`
2. Write "NEEDS_HUMAN: description" in `.spinstate/status.txt`
3. Commit and stop
