# Project Checklist / Projektový Checklist
Generated: {TIMESTAMP}
Project: {PROJECT_NAME}

---

## Phase 1: Planning / Plánování
Agent: PLANNER
Status: [ ] Not Started / [~] In Progress / [x] Complete

- [ ] Read all documentation
- [ ] Analyze existing codebase (if any)
- [ ] Create architecture.md
- [ ] Create plan.md with phases
- [ ] Define technology decisions
- [ ] Identify dependencies and risks

---

## Phase 2: Design / Design
Agent: DESIGNER
Status: [ ] Not Started

- [ ] Review plan.md
- [ ] Create component specifications
- [ ] Define design tokens (colors, typography, spacing)
- [ ] Create layout patterns
- [ ] Document UI/UX decisions

---

## Phase 3: Infrastructure / Infrastruktura
Agent: ENGINEER
Status: [ ] Not Started

- [ ] Project structure setup
- [ ] Docker configuration
- [ ] Database schema and migrations
- [ ] API routing structure
- [ ] Environment configuration
- [ ] CI/CD basics

---

## Phase 4: Development / Vývoj
Agent: DEVELOPER
Status: [ ] Not Started

### Backend
- [ ] Core models
- [ ] API endpoints
- [ ] Business logic
- [ ] Authentication/Authorization

### Frontend
- [ ] Component structure
- [ ] State management
- [ ] API integration
- [ ] Styling implementation

### Integration
- [ ] Backend-Frontend connection
- [ ] Error handling
- [ ] Loading states

---

## Phase 5: Review / Revize
Agent: REVIEWER
Status: [ ] Not Started

- [ ] Code quality check
- [ ] Security review
- [ ] Performance analysis
- [ ] Best practices verification
- [ ] Documentation completeness

---

## Phase 6: Testing / Testování
Agent: TESTER
Status: [ ] Not Started

- [ ] Unit tests
- [ ] Integration tests
- [ ] E2E tests (if applicable)
- [ ] Manual testing
- [ ] Edge cases

---

## Phase 7: Supervision / Supervize
Agent: SUPERVISOR
Status: [ ] Not Started

- [ ] Collision detection
- [ ] Integration verification
- [ ] Pattern analysis
- [ ] Evolution recommendations

---

## Notes / Poznámky

### Blockers / Blokátory
(Add any blocking issues here)

### Decisions / Rozhodnutí
(Log important decisions here)

### Questions / Dotazy
(Questions that need human input)
