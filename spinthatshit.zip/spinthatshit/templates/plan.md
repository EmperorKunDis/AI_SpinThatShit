# Project Plan / Projektový Plán
Generated: {TIMESTAMP}
Project: {PROJECT_NAME}

---

## Executive Summary / Shrnutí

{Brief description of the project and its goals}

---

## Architecture Overview / Přehled Architektury

### Tech Stack
- **Backend:** {e.g., Django 5.0+}
- **Frontend:** {e.g., Angular 19.2.16}
- **Database:** {e.g., PostgreSQL 16 with pgvector}
- **Styling:** {e.g., Tailwind CSS 3.4}
- **State Management:** {e.g., @ngrx/signals}

### Folder Structure
```
project/
├── backend/
│   ├── api/
│   ├── core/
│   └── ...
├── frontend/
│   ├── src/
│   └── ...
└── docker/
```

---

## Phase Breakdown / Rozdělení Fází

### Phase 1: Planning
**Agent:** PLANNER
**Duration:** ~15 minutes
**Objectives:**
- Understand requirements
- Design architecture
- Create development roadmap

**Deliverables:**
- architecture.md
- checklist.md
- This plan.md

**Dependencies:** None

---

### Phase 2: Design
**Agent:** DESIGNER  
**Duration:** ~20 minutes
**Objectives:**
- Component specifications
- Design system setup
- Layout patterns

**Deliverables:**
- design/components.md
- design/tokens.md
- design/layouts.md

**Dependencies:** Phase 1

---

### Phase 3: Infrastructure
**Agent:** ENGINEER
**Duration:** ~30 minutes
**Objectives:**
- Project scaffolding
- Docker setup
- Database initialization
- API structure

**Deliverables:**
- Working project skeleton
- Docker configuration
- Database migrations
- Base configuration

**Dependencies:** Phase 1, Phase 2

---

### Phase 4: Development
**Agent:** DEVELOPER
**Duration:** Variable (may span multiple sessions)
**Objectives:**
- Implement core features
- Build UI components
- Create API endpoints
- Integrate systems

**Deliverables:**
- Functional application
- Working features per checklist

**Dependencies:** Phase 3

---

### Phase 5: Review
**Agent:** REVIEWER
**Duration:** ~15 minutes
**Objectives:**
- Code quality audit
- Security check
- Performance review
- Best practices

**Deliverables:**
- review.md with findings
- Updated checklist with fixes

**Dependencies:** Phase 4

---

### Phase 6: Testing
**Agent:** TESTER
**Duration:** ~20 minutes
**Objectives:**
- Run existing tests
- Create new tests
- Manual verification
- Coverage analysis

**Deliverables:**
- test_report.md
- New test files
- Bug reports

**Dependencies:** Phase 5

---

### Phase 7: Supervision
**Agent:** SUPERVISOR
**Duration:** ~10 minutes
**Objectives:**
- Collision detection
- Integration check
- Pattern analysis
- Evolution suggestions

**Deliverables:**
- supervision_report.md
- Journal updates
- Evolution proposals

**Dependencies:** Phase 6

---

## Risk Assessment / Hodnocení Rizik

### Technical Risks
| Risk | Probability | Impact | Mitigation |
|------|-------------|--------|------------|
| {Risk 1} | {H/M/L} | {H/M/L} | {Strategy} |

### Process Risks
| Risk | Probability | Impact | Mitigation |
|------|-------------|--------|------------|
| Context overflow | M | M | Checkpoint at 50% |
| Agent failure | L | M | Auto-retry with fix |

---

## Success Criteria / Kritéria Úspěchu

1. [ ] All checklist items completed
2. [ ] All tests passing
3. [ ] No critical issues in review
4. [ ] Application runs successfully
5. [ ] Documentation complete

---

## Timeline Estimate / Odhad Časové Náročnosti

| Phase | Estimated Time | Notes |
|-------|----------------|-------|
| Planning | 15 min | One session |
| Design | 20 min | One session |
| Infrastructure | 30 min | One session |
| Development | 2-8 hours | Multiple sessions |
| Review | 15 min | One session |
| Testing | 20 min | One session |
| Supervision | 10 min | One session |
| **Total** | **3-10 hours** | Depends on complexity |

---

## Notes for Agents / Poznámky pro Agenty

- Always commit after each significant change
- Update checklist when completing tasks
- Write to handoff.md if stopping mid-task
- Read journal.md before starting
- Keep context usage under 50%
