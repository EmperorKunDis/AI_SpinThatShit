# Sample SaaS Project Documentation
# ==================================
# This is example documentation to test SpinThatShit

## Project: PostHub SaaS Platform

### Overview
PostHub is a social media content automation platform for the Czech market. 
It allows users to schedule, generate, and manage social media content across multiple platforms.

### Tech Stack
- **Frontend:** Angular 19.2.16 with Tailwind CSS 3.4
- **Backend:** Django 5.0+ with Django REST Framework
- **Database:** PostgreSQL 16 with pgvector extension
- **State Management:** @ngrx/signals
- **Authentication:** JWT tokens
- **API Structure:** REST, `/api/v1/...`

### Pricing Tiers (CZK/month)
| Tier | Price | Features |
|------|-------|----------|
| Basic | 990 CZK | 1 user, 3 social accounts, 50 posts/month |
| Pro | 2,490 CZK | 5 users, 10 social accounts, 500 posts/month, AI generation |
| Enterprise | 7,490 CZK | Unlimited users, unlimited accounts, custom AI personas |

### Core Features

#### 1. User Management
- Registration/Login
- Team management
- Role-based access (Admin, Editor, Viewer)

#### 2. Social Account Connection
- Connect Facebook, Instagram, LinkedIn, Twitter/X
- OAuth2 integration
- Account health monitoring

#### 3. Content Calendar
- Visual calendar view
- Drag-and-drop scheduling
- Multi-platform posting
- Time zone support

#### 4. AI Content Generation
- Multiple AI personas
- Content templates
- Tone customization
- Czech language optimization

#### 5. Subscription & Billing
- Stripe integration
- Czech payment methods (bank transfer)
- Invoice generation
- Usage tracking

### Database Schema (Core Tables)

```sql
-- Users
CREATE TABLE users (
    id UUID PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    organization_id UUID REFERENCES organizations(id),
    role VARCHAR(50) DEFAULT 'viewer',
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Organizations (multi-tenant)
CREATE TABLE organizations (
    id UUID PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    subscription_tier VARCHAR(50) DEFAULT 'basic',
    subscription_status VARCHAR(50) DEFAULT 'trial',
    billing_email VARCHAR(255),
    created_at TIMESTAMP DEFAULT NOW()
);

-- Social Accounts
CREATE TABLE social_accounts (
    id UUID PRIMARY KEY,
    organization_id UUID REFERENCES organizations(id),
    platform VARCHAR(50) NOT NULL, -- facebook, instagram, linkedin, twitter
    account_name VARCHAR(255),
    access_token TEXT,
    refresh_token TEXT,
    token_expires_at TIMESTAMP,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Posts
CREATE TABLE posts (
    id UUID PRIMARY KEY,
    organization_id UUID REFERENCES organizations(id),
    social_account_id UUID REFERENCES social_accounts(id),
    content TEXT NOT NULL,
    media_urls JSONB,
    scheduled_at TIMESTAMP,
    published_at TIMESTAMP,
    status VARCHAR(50) DEFAULT 'draft', -- draft, scheduled, published, failed
    ai_generated BOOLEAN DEFAULT false,
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT NOW()
);

-- AI Personas
CREATE TABLE ai_personas (
    id UUID PRIMARY KEY,
    organization_id UUID REFERENCES organizations(id),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    tone VARCHAR(100), -- professional, casual, humorous, etc.
    language VARCHAR(10) DEFAULT 'cs',
    system_prompt TEXT,
    is_default BOOLEAN DEFAULT false,
    created_at TIMESTAMP DEFAULT NOW()
);
```

### API Endpoints (v1)

#### Authentication
- `POST /api/v1/auth/register/` - User registration
- `POST /api/v1/auth/login/` - Get JWT token
- `POST /api/v1/auth/refresh/` - Refresh token
- `POST /api/v1/auth/logout/` - Invalidate token

#### Users
- `GET /api/v1/users/me/` - Current user profile
- `PUT /api/v1/users/me/` - Update profile
- `GET /api/v1/users/` - List organization users (admin)

#### Social Accounts
- `GET /api/v1/social-accounts/` - List connected accounts
- `POST /api/v1/social-accounts/connect/` - Initiate OAuth
- `DELETE /api/v1/social-accounts/{id}/` - Disconnect account

#### Posts
- `GET /api/v1/posts/` - List posts (with filters)
- `POST /api/v1/posts/` - Create post
- `PUT /api/v1/posts/{id}/` - Update post
- `DELETE /api/v1/posts/{id}/` - Delete post
- `POST /api/v1/posts/{id}/publish/` - Publish immediately
- `POST /api/v1/posts/{id}/schedule/` - Schedule post

#### AI Generation
- `POST /api/v1/ai/generate/` - Generate content
- `GET /api/v1/ai/personas/` - List personas
- `POST /api/v1/ai/personas/` - Create persona

#### Subscriptions
- `GET /api/v1/subscriptions/current/` - Current subscription
- `POST /api/v1/subscriptions/upgrade/` - Upgrade tier
- `GET /api/v1/subscriptions/invoices/` - Invoice history

### Frontend Components

#### Pages
- `/login` - Login page
- `/register` - Registration
- `/dashboard` - Main dashboard
- `/calendar` - Content calendar
- `/posts` - Post management
- `/accounts` - Social account management
- `/ai` - AI content generation
- `/settings` - User/org settings
- `/billing` - Subscription management

#### Key Components
- `CalendarComponent` - Visual calendar with drag-drop
- `PostEditorComponent` - Rich text editor for posts
- `AiGeneratorComponent` - AI content generation interface
- `AccountConnectorComponent` - OAuth flow handling
- `SubscriptionSelectorComponent` - Pricing tier selection

### Environment Variables

```env
# Backend
DATABASE_URL=postgresql://user:pass@localhost:5432/posthub
SECRET_KEY=your-django-secret-key
DEBUG=True
ALLOWED_HOSTS=localhost,127.0.0.1

# OAuth
FACEBOOK_APP_ID=xxx
FACEBOOK_APP_SECRET=xxx
INSTAGRAM_APP_ID=xxx
INSTAGRAM_APP_SECRET=xxx

# AI
OPENAI_API_KEY=xxx
ANTHROPIC_API_KEY=xxx

# Payments
STRIPE_SECRET_KEY=xxx
STRIPE_WEBHOOK_SECRET=xxx

# Frontend
API_URL=http://localhost:8000/api/v1
```

### UI/UX Guidelines

- **Colors:** 
  - Primary: #6366F1 (Indigo)
  - Secondary: #10B981 (Emerald)
  - Danger: #EF4444 (Red)
  - Background: #F9FAFB (Light Gray)

- **Typography:**
  - Headings: Inter, semi-bold
  - Body: Inter, regular
  - Code: JetBrains Mono

- **Spacing:** Based on Tailwind's default scale (4px base)

- **Components:** Use Tailwind UI patterns, glassmorphism for cards

### Development Notes

1. Start with authentication flow
2. Then social account connection
3. Then post CRUD
4. Then calendar view
5. Then AI integration
6. Finally billing/subscriptions

Priority: Get MVP working first (auth + posts + one platform), then expand.
